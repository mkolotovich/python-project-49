#!/usr/bin/env python3

import brain_games.src.games.calc


def main():
    brain_games.src.games.calc.startGame()


if __name__ == '__main__':
    main()
