#!/usr/bin/env python3

import brain_games.src.games.gcd


def main():
    brain_games.src.games.gcd.start_game()


if __name__ == '__main__':
    main()
