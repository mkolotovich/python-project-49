#!/usr/bin/env python3

import brain_games.src.games.progression


def main():
    brain_games.src.games.progression.start_game()


if __name__ == '__main__':
    main()
