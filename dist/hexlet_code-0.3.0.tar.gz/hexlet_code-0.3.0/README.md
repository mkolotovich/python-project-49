# Python проект - "Игры разума"
[![Actions Status](https://github.com/mkolotovich/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/mkolotovich/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/9ee7196caf108231656d/maintainability)](https://codeclimate.com/github/mkolotovich/python-project-49/maintainability)