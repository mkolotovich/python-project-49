import brain_games.cli
import prompt
from random import randint

def is_even(num):
    print(num % 2)
    return num % 2

def main():
    name = brain_games.cli.welcome_user()
    win_count = 3
    count = 0
    print('Answer "yes" if the number is even, otherwise answer "no".')
    while(count < win_count):
        random_number = randint(1, 100)
        print(f'Question: {random_number}')
        answer = prompt.string('Your answer: ')
        if (answer == 'yes' and is_even(answer)) or (answer == 'no' and not is_even(answer)):
            print("Correct!")
        else:
            print(answer + " is wrong answer ;(. Correct answer was 'no'.")
    print("Congratulations, " + name + "!")

if __name__ == '__main__':
    main()