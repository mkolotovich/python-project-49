#!/usr/bin/env python3

import brain_games.src.games.even


def main():
    brain_games.src.games.even.startGame()


if __name__ == '__main__':
    main()
